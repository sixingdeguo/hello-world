import openai
import os
from openai import AzureOpenAI


# key：f5b654304afb47e497b6e64729ab3692
# end_point：https://geely-14-chatgpt-010.openai.azure.com/
# 部署名：
# o1-mini
# o1-preview


openai.api_key = "f5b654304afb47e497b6e64729ab3692"
openai.api_base = "https://geely-14-chatgpt-010.openai.azure.com/"

messages = [
    {"role": "user", "content": "w"}
]


def ask_gpt_4o(message):
    try:
        response = openai.chat.completions.create(
        model="o1-preview",
        messages=message,
        timeout=90,
        )       
        text = response.get("choices")[0]["message"]["content"]
        return text
    except Exception as e:
        print(f"调用GPT出现错误: {e}")
        return None


def preview_demo():
    client = AzureOpenAI(
        azure_endpoint="https://geely-14-chatgpt-010.openai.azure.com/",
        api_key="f5b654304afb47e497b6e64729ab3692",
        api_version="2024-02-01"
    )

    response = client.chat.completions.create(
    model="o1-preview", # model = "deployment_name".
    messages=[
        # {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "帮我总结一下《追忆似水年华》这本书"},
    ]
    )

    print(response.choices[0].message.content)


def mini_demo():
    client = AzureOpenAI(
    azure_endpoint="https://geely-14-chatgpt-010.openai.azure.com/",
    api_key="f5b654304afb47e497b6e64729ab3692",
    api_version="2024-02-01"
    )

    response = client.chat.completions.create(
    model="o1-mini", # model = "deployment_name".
    messages=[
        # {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "帮我总结一下《追忆似水年华》这本书"},
    ]
    )

    print(response.choices[0].message.content)


if __name__ == '__main__':
    # 这里是示例的提问内容，你可以替换成你实际想询问的内容
    # answer = ask_gpt_4o(messages)
    # if answer:
    # print(answer)
    preview_demo()
    # mini_demo()