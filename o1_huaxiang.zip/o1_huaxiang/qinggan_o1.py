import openai
import os
from openai import AzureOpenAI


# key：f5b654304afb47e497b6e64729ab3692
# end_point：https://geely-14-chatgpt-010.openai.azure.com/
# 部署名：
# o1-mini
# o1-preview
openai.api_key = "f5b654304afb47e497b6e64729ab3692"
openai.api_base = "https://geely-14-chatgpt-010.openai.azure.com/"

messages = [
    {"role": "user", "content": "w"}
]


def ask_gpt_4o(message):
    try:
        response = openai.chat.completions.create(
        model="o1-preview",
        messages=message,
        timeout=90,
        )       
        text = response.get("choices")[0]["message"]["content"]
        return text
    except Exception as e:
        print(f"调用GPT出现错误: {e}")
        return None


def preview_demo(messages = None):
    client = AzureOpenAI(
        azure_endpoint="https://geely-14-chatgpt-010.openai.azure.com/",
        api_key="f5b654304afb47e497b6e64729ab3692",
        api_version="2024-02-01"
    )
    if not messages:
        messages=[
            # {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "帮我总结一下《追忆似水年华》这本书"},
        ]

    response = client.chat.completions.create(
        model = "o1-preview", # model = "deployment_name".)
        messages = messages
    )
    # print(response.choices[0].message.content)
    return response


def mini_demo(messages = None):
    client = AzureOpenAI(
        azure_endpoint="https://geely-14-chatgpt-010.openai.azure.com/",
        api_key="f5b654304afb47e497b6e64729ab3692",
        api_version="2024-02-01"
    )

    if not messages:
        messages=[
            # {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "帮我总结一下《追忆似水年华》这本书"},
        ]

    response = client.chat.completions.create(
        model = "o1-mini", # model = "deployment_name".)
        messages = messages
    )
    print(response.choices[0].message.content)
    return response





if __name__ == '__main__':
    # 读取相声文本
    file_path = '/home/geely-wubantu/code/o1_huaxiang/Crosstalk-Generation-master/data/crosstalk/郭德纲于谦《我是黑社会》相声文本.txt'
    with open(file_path, "r", encoding="gbk") as file: # 确保文件编码正确
        text_content = file.read() # 读取整个文件内容为字符串

    # 提示词第二部分
    prompt_1 = '把逗和捧的语言模式总结为一个有限状态机，即“条件”+“输入”决定输出的一些规则，并配上具体示例。'

    messages = [{"role": "user", "content": text_content + prompt_1}]
    rule_response = preview_demo(messages = messages)
    messages.append({"role": "assistant", "content": rule_response.choices[0].message.content})
    prompt_2 = '根据上面的规则，并强烈依照示例的语言风格，围绕大模型训练，创作一首相声《我是怎么成为AI情感陪伴训练行当的黑社会的》'
    messages.append({"role": "user", "content": prompt_2})
    
    final_response_0 = preview_demo(messages = messages)
    messages = [{"role": "user", "content": rule_response.choices[0].message.content + prompt_2}]
    final_response_1 = preview_demo(messages = messages)

    output_file = 'crosstalk_gen.txt'
    with open(output_file, "w", encoding="utf-8") as file: # 确保文件编码正确
        file.write('#'*20+'多轮结果'+'#'*20)
        file.write(final_response_0.choices[0].message.content)
        file.write('#'*20+'单轮结果'+'#'*20)
        file.write(final_response_1.choices[0].message.content)


    # print(final_response_0.choices[0].message.content)

    # print(final_response_1.choices[0].message.content)
    # response.choices[0].message.content
    # messages .append({"role": "user", "content": text_content + prompt_1})

